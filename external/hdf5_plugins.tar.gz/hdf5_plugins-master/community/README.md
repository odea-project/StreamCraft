# HDF5 Community Filters

These filters are NOT built and deployed with the HDF5 library. They are supported
(or not) by the community. Even when unsupported and unmaintained, we attempt to provide code
and information to help anyone who encounters files that require these filters in the wild.

| Filter Plugin | Built and Tested? |
|---------|-------------|
|MAFISC|NO (broken)|
|SZ|NO (broken)|
